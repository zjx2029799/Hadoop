This directory contains templates for generating Eclipse files to configure
Eclipse for Hadoop development.

For further information please consult

http://wiki.apache.org/hadoop/EclipseEnvironment 
